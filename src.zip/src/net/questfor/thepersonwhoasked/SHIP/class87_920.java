package net.questfor.thepersonwhoasked.SHIP;


import net.questfor.thepersonwhoasked.Main;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class class87_920 extends JFrame{
        class92873_02 panel;
        class87_920() throws IOException {
        this.setBackground(Main.window.getBackground());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(Main.window.getSize());
        this.setLocation(Main.window.getLocationOnScreen());
        this.setBackground(Color.black);
        this.setForeground(Color.black);
        this.setVisible(true);
        JLabel background = new JLabel();
        background.setBackground(Color.black);
        this.add(background);
        panel = new class92873_02();
        this.add(panel);
        this.setIconImage(Main.window.getIconImage());
        }


}



